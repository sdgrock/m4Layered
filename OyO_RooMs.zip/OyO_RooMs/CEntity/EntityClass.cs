﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CEntity
{
    public class EntityClass
    {
        public int CUSTOMER_ID { get; set; }
        public string CUSTOMER_NAME { get; set; }
        public string ADDRESS { get; set; }
        public string ID_DOC { get; set; }
        public string CITY { get; set; }
        public DateTime DATE_IN { get; set; }
        public DateTime DATE_OUT { get; set; }
        public string ROOM_TYPE { get; set; }
        public int HOTEL_ID { get; set; }
    }
}
