﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDal;
using CEntity;

namespace CBal
{
    public class BalClass
    {
        public static bool AddCustomerDAL(EntityClass aobj)
        {
            return new DalClass().AddCustomerDAL(aobj);
        }
    }
}
