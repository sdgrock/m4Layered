﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using CEntity;
using CException;


namespace CDal
{
    public class DalClass
    {
        public bool AddCustomerDAL(EntityClass aobj)
        {
            bool adminsAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();

                command.CommandText = "addCustomer";

                DbParameter param = command.CreateParameter();

                param = command.CreateParameter();
                param.ParameterName = "@customername";
                param.DbType = DbType.String;
                param.Value = aobj.CUSTOMER_NAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = aobj.ADDRESS;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@idDoc";
                param.DbType = DbType.String;
                param.Value = aobj.ID_DOC;
                command.Parameters.Add(param);



                param = command.CreateParameter();
                param.ParameterName = "@datein";
                param.DbType = DbType.DateTime;
                param.Value = aobj.DATE_IN;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@dateout";
                param.DbType = DbType.DateTime;
                param.Value = aobj.DATE_OUT;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@roomtype";
                param.DbType = DbType.String;
                param.Value = aobj.ROOM_TYPE;
                command.Parameters.Add(param);



                param = command.CreateParameter();
                param.ParameterName = "@hotelid";
                param.DbType = DbType.Int32;
                param.Value = aobj.HOTEL_ID;
                command.Parameters.Add(param);



                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                {
                    adminsAdded = true;
                }
            }
            catch (DbException ex)
            {

                throw new ExceptionClass(ex.Message);
            }
            return adminsAdded;

        }
    }
}
