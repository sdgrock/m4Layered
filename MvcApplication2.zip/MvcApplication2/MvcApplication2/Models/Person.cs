﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcApplication2.Models
{
    public class Person
    {
        [Required(ErrorMessage = "Person ID is required")]
        [Range(minimum:1,maximum:500)]
        public int PersonID { get; set; }
      
        [Required(ErrorMessage = "Person Name is required")]
        [RegularExpression("^([A-Z][a-zA-Z]+)$",
            ErrorMessage="Invalid Person Name")]
        [StringLength(maximumLength:40,MinimumLength=3,
            ErrorMessage="3-40 characters")]
        public string PersonName { get; set; }
    }
}