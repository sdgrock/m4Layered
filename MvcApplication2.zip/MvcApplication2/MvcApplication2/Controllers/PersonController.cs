﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;
using System.Net;

namespace MvcApplication2.Controllers
{
    public class PersonController : Controller
    {
        static List<Person> persons = new List<Person>
            {
                new Person {PersonID=101,PersonName="Ram"},
                new Person {PersonID=102,PersonName="Sam"},
                new Person {PersonID=103,PersonName="Sita"},
                new Person {PersonID=104,PersonName="Gita"},
                new Person {PersonID=105,PersonName="Riya"},
            };
        //
        // GET: Person

        //GET A BLANK FORM-HTTPGET
        [HttpGet]
        public ActionResult DisplayPersons()
        {
            //List<Person> persons = new List<Person>
            //{
            //    new Person {PersonID=101,PersonName="Ram"},
            //    new Person {PersonID=102,PersonName="Sam"},
            //    new Person {PersonID=103,PersonName="Sita"},
            //    new Person {PersonID=104,PersonName="Gita"},
            //    new Person {PersonID=105,PersonName="Riya"},
            //};
            return View(persons);
        }
        [HttpGet]
        
        public ActionResult CreatePersons()
        {           
            return View();
        }

        //POST MEANS SUBMIT-HTTPPOST
        [HttpPost]
        public ActionResult CreatePersons(Person person)
        {
            if (ModelState.IsValid)
            {
                persons.Add(person);
                //return View("DisplayPersons");
                return RedirectToAction("DisplayPersons");
            }
            else 
            {
                return View();
            }         
        }

        [HttpGet]
         public ActionResult DeleteAPerson(int? id)
        {
            Person person = persons.Find(x => x.PersonID == id);
            if (person != null)
            {
                return View(person);
            }
            else
            {
                return Content("ID is wrong");
            }
        }

        [HttpPost, ActionName("DeleteAPerson")]
        public ActionResult DeleteAPersonConfirmed(int? id)
        {
             Person person = persons.Find(x => x.PersonID == id);
             if (person != null)
             {
                 persons.Remove(person);
                 return RedirectToAction("DisplayPersons");
             }
             else
             {
                 return Content("ID is wrong");
             }
        }


        [HttpGet]
        public ActionResult DeletePer()
        {
            return View();          
        }

        [HttpPost]
        public ActionResult DeletePer(Person p)
        {
            Person person = persons.Find(x => x.PersonID == p.PersonID);
            if (person != null)
            {
                persons.Remove(person);
                return RedirectToAction("DisplayPersons");
            }
            else
            {
                return Content("ID is wrong");
            }
        }

        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Person person = persons.Find(x => x.PersonID == id);

            if (person == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
            }
            return View(person);
        }

        [HttpPost]
        public ActionResult Edit(Person p)
        {
            Person person = null;
            if (ModelState.IsValid)
            {
                person = persons.Find(x => x.PersonID == p.PersonID);
                if (person != null)
                {
                    person.PersonName = p.PersonName;
                    return RedirectToAction("DisplayPersons");
                }
            }
            return View();
        }
    }
}
