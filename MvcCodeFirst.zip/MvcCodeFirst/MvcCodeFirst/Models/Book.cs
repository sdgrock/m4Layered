﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MvcCodeFirst.Models
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookName { get; set; }
        public int Price { get; set; }
        public int YearPublish { get; set; }
        public int AuthorID { get; set; }
        public Author Author { get; set; }
    }
    public class Author
    {
        public int AuthorID { get; set; }
        public string AuthorName { get; set; }
        public ICollection<Book> Books { get; set; }
    }
    public class MyDBContext : DbContext
    {
        public MyDBContext() : base("MyConString") 
        {
        }

        public DbSet<Book> Books { get; set; }

        public DbSet<Author> Authors { get; set; }
    }
   
}