﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDAL;
using CEntity;
using CException;

namespace CBAL
{
    public class BALClass
    {
        public static List<RegEntity> getAllInstituteBAL()
        {
            return new DALClass().getAllInstitute();
        }
        
        public static List<RegEntity> getAllCourseBAL()
        {
            return new DALClass().getAllCourse();
        }
        
        public static bool AddAdmissionDAL(RegEntity aobj)
        {
            return new DALClass().AddAdmissionDAL(aobj);
        }

        
        public static RegEntity SearchStudBL(string searchStudName)
        {
            RegEntity searchStud = null;
            try
            {
                DALClass studDAL = new DALClass();
                searchStud = studDAL.SearchStudDAL(searchStudName);
            }
            catch (ExceptionClass ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchStud;

        }

        public static bool UpdateStudBL(RegEntity updateStud)
        {
            bool studUpdated = false;
            try
            {              
                   DALClass studDAL = new DALClass();
                   studUpdated = studDAL.UpdateStudDAL(updateStud);              
            }
            catch (ExceptionClass)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studUpdated;
        }

        public static List<RegEntity> ShowAllStudBL()
        {
            List<RegEntity> myList = null;
            try
            {
                DALClass studDAL = new DALClass();
                myList = studDAL.ShowAllStudDAL();
            }
            catch (ExceptionClass ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return myList;
        }
       
    }
}
