﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace MvcDb.Controllers
{
    public class PersonController : Controller
    {
        static List<Person> persons = new List<Person>
                {
                    new Person {PersonID=101,PersonName="Raman"},
                    new Person {PersonID=102,PersonName="Samred"},
                    new Person {PersonID=103,PersonName="Sita"},
                    new Person {PersonID=104,PersonName="Geet"},
                    new Person {PersonID=105,PersonName="Riya"},
                };

        public SohiniEntities context = new SohiniEntities();
        // GET: /Person/

        //Display from database table
        public ActionResult DisplayPerson(Person person)
        {
            if (context.People.Count() == 0)
            {

                foreach (Person item in context.People )
                {
                    context.People.Add(item);
                }
                context.SaveChanges();

            }
            var data = (context.People).ToList();
            return View(data);
        }

        //update as far condition on the existing datatable
        public ActionResult UpdatePerson(Person person)
        {
            var data = (context.People.Where(x => x.PersonName.Length < 5)).ToList();
            foreach (var item in data)
            {
                item.PersonName = item.PersonName + "*";

            }
            context.SaveChanges();

            return View("DisplayPerson", data);

        }

        //delete table data based on condition
        public ActionResult DeletePerson(Person person)
        {
            var data = (context.People.Where(x => x.PersonName.Length < 5)).ToList();
            foreach (var item in data)
            {
                context.People.Remove(item);
            }
            context.SaveChanges();
            return View("DisplayPerson", data);
        }


        //delete using hyperlink
        public ActionResult Delete(int? id)
        {
            Person person = context.People.Where(x => x.PersonID == id).FirstOrDefault();
            if (person != null)
            {
                context.People.Remove(person);
                context.SaveChanges();
            }
            return RedirectToAction("DisplayPerson");
        }

        //Adding Person 
        public ActionResult AddPerson()
        {

            if (context.People.Count() == 0)
            {
                foreach (var item in persons)
                {
                    context.People.Add(item);
                    context.SaveChanges();
                }
               
                return RedirectToAction("DisplayPerson");
            }
            var data = (context.People).ToList();
            return View(data);
                 
        }

    }
}
