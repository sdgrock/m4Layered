﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CException
{
    public class ExceptionClass : ApplicationException
    {
          public ExceptionClass() : base()
        {

        }
        public ExceptionClass(string message) : base(message)
        {

        }
        public ExceptionClass(string message, Exception innerException) : base(message, innerException)           
        {

        }
    }
}
