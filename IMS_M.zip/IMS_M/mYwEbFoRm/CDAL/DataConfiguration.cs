﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace CDAL
{
    class DataConfiguration
    {
       
        private static string providerName;

        public static string ProviderName
        {
            get { return DataConfiguration.providerName; }
            set { DataConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return DataConfiguration.connectionString; }
            set { DataConfiguration.connectionString = value; }
        }

        static DataConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["Training"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["Training"].ConnectionString;
        }

    }
}
