﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CBAL;
using CEntity;
using CException;

namespace mYwEbFoRm
{
    public partial class RegistrationWeb : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<RegEntity> institutelist = BALClass.getAllInstituteBAL();
                foreach (var item in institutelist)
                {
                    DropDownList1.Items.Add(item.INSTITUTE_NAME);
                }

                List<RegEntity> courseslist = BALClass.getAllCourseBAL();
                foreach (var item in courseslist)
                {
                    DropDownList2.Items.Add(item.COURSE_NAME);
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            RegEntity fobj = new RegEntity();
            fobj.INSTITUTE_NAME = DropDownList1.Text;
            fobj.COURSE_NAME = DropDownList2.Text;
            fobj.STUDENT_NAME = TextBox1.Text;
            fobj.DOB = Convert.ToDateTime(TextBox2.Text);

            bool result = BALClass.AddAdmissionDAL(fobj);

            if (result)
            {
                Label7.Text = "Registered";
            }
            else
                Label7.Text = "Not Registered";
        }

        protected void srchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string searchStudName = TextBox1.Text;
                RegEntity searchStud = BALClass.SearchStudBL(searchStudName);

                if (searchStud != null)
                {
                    TextBox2.Text = Convert.ToString(searchStud.DOB);
                    DropDownList1.SelectedItem.Text = searchStud.INSTITUTE_NAME;
                    DropDownList2.SelectedItem.Text = searchStud.COURSE_NAME;
                }
                else
                {
                    Label7.Text = "No students available";
                }
                
            }
            catch(ExceptionClass ex)
            {
                throw ex;
            }
        }

        protected void updtbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string updateStudName = Convert.ToString(TextBox1.Text);

                RegEntity updatedStud = BALClass.SearchStudBL(updateStudName);
                if (updatedStud != null)
                {

                    updatedStud.STUDENT_NAME = TextBox1.Text;
                    updatedStud.DOB = Convert.ToDateTime(TextBox2.Text);
                    updatedStud.INSTITUTE_NAME = DropDownList1.SelectedItem.Text;
                    updatedStud.COURSE_NAME = DropDownList2.SelectedItem.Text;
                   
                    bool studUpdated = BALClass.UpdateStudBL(updatedStud);
                    if (studUpdated)
                        Label7.Text = "Student Details Updated";
                    else
                        Label7.Text = "Student Details not Updated";
                }
                else
                {
                    Label7.Text = "No Employee Details Available";
                }


            }
            catch (ExceptionClass ex)
            {
                throw ex;
            }
        }
    }
}