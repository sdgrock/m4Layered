﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CBAL;
using CEntity;

namespace mYwEbFoRm
{
    public partial class RegistrationWeb : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                List<RegEntity> institutelist = BALClass.getAllInstituteBAL();
                foreach (var item in institutelist)
                {
                    DropDownList1.Items.Add(item.INSTITUTE_NAME);
                }

                List<RegEntity> courseslist = BALClass.getAllCourseBAL();
                foreach (var item in courseslist)
                {
                    DropDownList2.Items.Add(item.COURSE_NAME);
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            RegEntity fobj = new RegEntity();
            fobj.INSTITUTE_NAME = DropDownList1.Text;
            fobj.COURSE_NAME = DropDownList2.Text;
            fobj.STUDENT_NAME = TextBox1.Text;
            fobj.DOB = Convert.ToDateTime(TextBox2.Text);

            bool result = BALClass.AddAdmissionDAL(fobj);

            if (result)
            {
                Label7.Text = "Registered";
            }
            else
                Label7.Text = "Not Registered";
        }
    }
}