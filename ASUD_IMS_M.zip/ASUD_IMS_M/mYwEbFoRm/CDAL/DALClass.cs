﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using CEntity;
using CException;

namespace CDAL
{
    public class DALClass
    {
        public List<RegEntity> getAllCourse()
        {
            List<RegEntity> clist = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "discourse";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    clist = new List<RegEntity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        RegEntity obj = new RegEntity();
                  
                        obj.COURSE_NAME = (string)dataTable.Rows[rowCounter][0];
                        clist.Add(obj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return clist;
        }

        public List<RegEntity> getAllInstitute()
        {
            List<RegEntity> ilist = null;

            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "disinstitute";

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    ilist = new List<RegEntity>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        RegEntity obj = new RegEntity();
                        obj.INSTITUTE_NAME = (string)dataTable.Rows[rowCounter][0];
                     
                        ilist.Add(obj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new Exception(ex.Message);
            }
            return ilist;
        }

        public bool AddAdmissionDAL(RegEntity aobj)
        {
            bool adminsAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                
                command.CommandText = "aaddAdmission";
              
                DbParameter param = command.CreateParameter();

                param = command.CreateParameter();
                param.ParameterName = "@studentname";
                param.DbType = DbType.String;
                param.Value = aobj.STUDENT_NAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Coursename";
                param.DbType = DbType.String;
                param.Value = aobj.COURSE_NAME;
                command.Parameters.Add(param);

                
                param = command.CreateParameter();
                param.ParameterName = "@Institutename";
                param.DbType = DbType.String;
                param.Value = aobj.INSTITUTE_NAME;
                command.Parameters.Add(param);


                
                param = command.CreateParameter();
                param.ParameterName = "@dateofbirth";
                param.DbType = DbType.DateTime;
                param.Value = aobj.DOB;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@instituteid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@courseid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@studentid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@admissionid";
                param.DbType = DbType.Int32;
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                {
                    aobj = new RegEntity();
                    adminsAdded = true;
                    aobj.ADMISSION_ID = Convert.ToInt32(command.Parameters[7].Value);
                    aobj.STUDENT_ID = Convert.ToInt32(command.Parameters[6].Value);
                    aobj.COURSE_ID = Convert.ToInt32(command.Parameters[5].Value);
                    aobj.INSTITUTE_ID = Convert.ToInt32(command.Parameters[4].Value);
                }
            }
            catch (DbException ex)
            {
                
                throw new ExceptionClass(ex.Message);
            }
            return adminsAdded;

        }

        public RegEntity SearchStudDAL(string searchStudName)
        {
            RegEntity searchStud = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspSearchStud";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@studentname";
                param.DbType = DbType.String;
                param.Value = searchStudName;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchStud = new RegEntity();

                    
                    searchStud.DOB = Convert.ToDateTime(dataTable.Rows[0][0]) ;
                    searchStud.INSTITUTE_NAME = dataTable.Rows[0][1].ToString();
                    searchStud.COURSE_NAME = dataTable.Rows[0][2].ToString();

                }
            }
            catch (DbException ex)
            {
                throw new ExceptionClass(ex.Message);
            }
            return searchStud;
        }


        public bool UpdateStudDAL(RegEntity updateStud)
        {
            bool studUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspUpdateStud";

                DbParameter param = command.CreateParameter();

                param = command.CreateParameter();
                param.ParameterName = "@studentname";
                param.DbType = DbType.String;
                param.Value = updateStud.STUDENT_NAME;
                command.Parameters.Add(param);

               
                param = command.CreateParameter();
                param.ParameterName = "@Coursename";
                param.DbType = DbType.String;
                param.Value = updateStud.COURSE_NAME;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@Institutename";
                param.DbType = DbType.String;
                param.Value = updateStud.INSTITUTE_NAME;
                command.Parameters.Add(param);



                param = command.CreateParameter();
                param.ParameterName = "@dateofbirth";
                param.DbType = DbType.DateTime;
                param.Value = updateStud.DOB;
                command.Parameters.Add(param);


                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    studUpdated = true;
            }
            catch (DbException ex)
            {
                throw new ExceptionClass(ex.Message);
            }
            return studUpdated;
        }


        


    }
}
