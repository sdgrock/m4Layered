﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcDemo.Models;

namespace MvcDemo.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/

        public ActionResult DisplayProduct()
        {
            northwindEntities1 context = new northwindEntities1();
            return View(context.Products);
        }

    }
}
