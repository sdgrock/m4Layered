﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDemo.Controllers
{
    public class DemoController : Controller
    {
        List<string> cities = new List<string> { "kolkata", "bangalore", "Mumbai", "Chennai" };
        //
        // GET: /Demo/

        public ActionResult Action2(int? id)
        {
            //return View();
            //return Content("My first MVC");
            //return Content("<h1>Hello World From MVC, id = " + id.ToString() + "</h1> ");

            //if (id == 0)
            //    return View();
            //else
            //    return View(id);

            // 1- return View();
            // 2- return View("View1");
            // 3- return View(id);
            // 4- return View("View1",id)

            if (id == null)
            {
                return View("Action2");
            }
            else
            {
                //ViewBag.myvalue = id;
                //return View(id);
                
                ViewBag.city = cities[(int)id];
                return View(id);
            }
        }

    }
}
