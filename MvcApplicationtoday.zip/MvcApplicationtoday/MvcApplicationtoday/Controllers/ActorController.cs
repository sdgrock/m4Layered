﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplicationtoday.Models;
using System.Data.Entity;


namespace MvcApplicationtoday.Controllers
{
    public class ActorController : Controller
    {
        static List<Actor> actors = new List<Actor>
                {
                    new Actor {ActorID=101,ActorName="Ramabcvbnmh"},
                    new Actor {ActorID=102,ActorName="Samredddesaa"},
                    new Actor {ActorID=103,ActorName="Sitasd"},
                    new Actor {ActorID=104,ActorName="Gitawdwdwdw"},
                    new Actor {ActorID=105,ActorName="Riyas"},
                };
        public MyDBContext context = new MyDBContext();
        // GET: /Actor/


        //Displaying names to the database 
        public ActionResult DisplayActors(Actor actor)
        {
            if (context.Actors.Count() == 0)
            {
                
                foreach (Actor item in actors)
                {
                    context.Actors.Add(item);                
                }
                context.SaveChanges();

            }
            var data = (context.Actors.Where(x => x.ActorName.Length > 4)).ToList();
            return View(data);
        }

        //Update names to database giving * after the name
        public ActionResult UpdateActors(Actor actor)
        {
                var data = (context.Actors.Where(x => x.ActorName.Length <7)).ToList();
                foreach (var item in data)
                {
                    item.ActorName = item.ActorName + "*";
                    
                }
                context.SaveChanges();
            
            return View("DisplayActors",data);
            
        }

        //Delete from Database
        public ActionResult DeleteActors(Actor actor)
        {
            var data = (context.Actors.Where(x => x.ActorName.Length < 16)).ToList();
            foreach (var item in data)
            {
                context.Actors.Remove(item);
            }
            context.SaveChanges();
            return View("DisplayActors", data);
        }

        //Hyperlink Deletion of names
        public ActionResult Delete(int? id)
        {
            Actor actor = context.Actors.Where(x => x.ActorID == id).FirstOrDefault();
            if (actor != null)
            {
                context.Actors.Remove(actor);
                context.SaveChanges();
            }
            return RedirectToAction("DisplayActors");
        }
    }
}
