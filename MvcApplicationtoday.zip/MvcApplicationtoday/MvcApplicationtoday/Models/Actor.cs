﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MvcApplicationtoday.Models
{
    public class Actor
    {
        public int ActorID { get; set; }

       
        public string ActorName { get; set; }
    }
    public class MyDBContext : DbContext
    {
        public MyDBContext()
            : base("MyConString")
        {
        }
        public DbSet<Actor> Actors { get; set; }
    }
}